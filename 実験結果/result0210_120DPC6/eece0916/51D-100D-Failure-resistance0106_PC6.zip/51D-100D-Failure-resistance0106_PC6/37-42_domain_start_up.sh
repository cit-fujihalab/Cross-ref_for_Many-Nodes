
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server37.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server38.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server39.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server40.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server41.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server42.py; bash"

