
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server7.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server8.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server9.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server10.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server11.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server12.py; bash"

