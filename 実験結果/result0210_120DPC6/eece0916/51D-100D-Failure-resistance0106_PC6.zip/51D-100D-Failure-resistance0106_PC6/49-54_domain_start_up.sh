
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server49.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server50.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server51.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server52.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server53.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server54.py; bash"

