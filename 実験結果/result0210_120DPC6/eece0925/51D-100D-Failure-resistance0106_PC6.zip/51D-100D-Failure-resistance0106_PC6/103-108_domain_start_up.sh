
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server103.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server104.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server105.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server106.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server107.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server108.py; bash"

