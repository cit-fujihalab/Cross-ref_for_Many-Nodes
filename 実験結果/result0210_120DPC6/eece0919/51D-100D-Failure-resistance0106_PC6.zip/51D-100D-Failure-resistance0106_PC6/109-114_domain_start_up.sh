
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server109.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server110.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server111.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server112.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server113.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server114.py; bash"

