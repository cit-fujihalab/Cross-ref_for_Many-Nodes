
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server91.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server92.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server93.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server94.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server95.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server96.py; bash"

