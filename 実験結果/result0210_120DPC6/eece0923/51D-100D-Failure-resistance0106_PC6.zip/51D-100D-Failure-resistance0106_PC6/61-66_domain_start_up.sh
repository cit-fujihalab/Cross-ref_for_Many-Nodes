
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server61.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server62.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server63.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server64.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server65.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server66.py; bash"

