# Failure-resistance
#t-耐故障

$ apt install python3-pip
$ pip3 install numpy
$ pip3 install PyCryptodome
$ pip3 install websocket_server==0.4
↑バージョン指定しないと実行不可
$ pip3 websocket_client
$ pip3 install plyvel
$ apt-get -y install python3-tk
