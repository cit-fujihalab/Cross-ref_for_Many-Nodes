
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server67.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server68.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server69.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server70.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server71.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server72.py; bash"

