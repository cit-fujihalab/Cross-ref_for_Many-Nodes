
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server97.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server98.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server99.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server100.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server101.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server102.py; bash"

