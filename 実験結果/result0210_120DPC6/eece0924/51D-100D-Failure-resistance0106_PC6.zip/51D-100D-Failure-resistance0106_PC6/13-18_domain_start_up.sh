
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server13.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server14.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server15.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server16.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server17.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server18.py; bash"

