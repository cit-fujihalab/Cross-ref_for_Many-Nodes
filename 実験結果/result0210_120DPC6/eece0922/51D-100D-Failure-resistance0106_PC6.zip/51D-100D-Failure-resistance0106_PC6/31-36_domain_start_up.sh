
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server31.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server32.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server33.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server34.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server35.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server36.py; bash"

