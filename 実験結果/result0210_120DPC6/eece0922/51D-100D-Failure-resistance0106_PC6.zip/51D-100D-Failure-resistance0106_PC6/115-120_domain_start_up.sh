
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server115.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server116.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server117.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server118.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server119.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server120.py; bash"

