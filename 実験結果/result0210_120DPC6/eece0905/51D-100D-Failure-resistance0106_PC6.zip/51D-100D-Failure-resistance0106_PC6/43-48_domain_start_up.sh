
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server43.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server44.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server45.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server46.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server47.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server48.py; bash"

