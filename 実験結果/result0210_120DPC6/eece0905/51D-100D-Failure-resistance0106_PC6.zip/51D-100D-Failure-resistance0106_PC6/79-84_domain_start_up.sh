
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server79.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server80.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server81.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server82.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server83.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server84.py; bash"

