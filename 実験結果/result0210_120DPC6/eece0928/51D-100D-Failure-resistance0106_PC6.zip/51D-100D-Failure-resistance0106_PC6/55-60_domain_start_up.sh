
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server55.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server56.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server57.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server58.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server59.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server60.py; bash"

