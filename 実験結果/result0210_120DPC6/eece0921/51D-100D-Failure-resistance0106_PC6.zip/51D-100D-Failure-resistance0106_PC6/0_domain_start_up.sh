
#!/bin/bash

gnome-terminal -- bash -c "python3 APP/owner_server0.py; bash"

