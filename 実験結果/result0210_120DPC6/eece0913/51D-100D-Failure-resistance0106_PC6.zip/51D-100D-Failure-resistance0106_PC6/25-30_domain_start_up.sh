
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server25.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server26.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server27.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server28.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server29.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server30.py; bash"

