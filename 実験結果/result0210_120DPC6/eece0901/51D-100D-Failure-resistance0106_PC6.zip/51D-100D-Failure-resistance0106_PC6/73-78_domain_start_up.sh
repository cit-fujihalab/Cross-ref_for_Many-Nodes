
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server73.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server74.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server75.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server76.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server77.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server78.py; bash"

