
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server19.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server20.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server21.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server22.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server23.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server24.py; bash"

