
#!/bin/bash


gnome-terminal -- bash -c "python3 APP/owner_server85.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server86.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server87.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server88.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server89.py; bash"
sleep 10
gnome-terminal -- bash -c "python3 APP/owner_server90.py; bash"

